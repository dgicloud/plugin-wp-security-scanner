# WP Security Scanner PRO

**Plugin Name:** WP Security Scanner PRO
**Description:** Escaneie seu site em busca de vulnerabilidades de segurança e desempenho, fornecendo dicas de blindagem.
**Version:** 5.3.1
**Author:** Thomas Marcelino
**Author URI:** https://wpmasters.com.br
**License:** GPL2

## Descrição

O WP Security Scanner PRO realiza uma verificação completa e aprofundada da segurança do seu ambiente WordPress, incluindo o Core, configurações do PHP, chaves de segurança, proteção contra força bruta, sistema de arquivos, banco de dados, e status de plugins e temas.

Ele identifica vulnerabilidades e fornece recomendações de blindagem claras e acionáveis para garantir a máxima segurança e performance do seu site.

## Instalação

1. Faça o upload da pasta `wp-security-scanner` para o diretório `/wp-content/plugins/`.
2. Ative o plugin através da tela 'Plugins' no WordPress.
3. Acesse 'Security Scanner' no menu de administração para iniciar a verificação.

## Changelog

**5.3.1 (2025-10-02)**
* Refatoração completa para seguir os padrões de desenvolvimento WP Masters.
* Implementação de versionamento automático de assets (JS/CSS) para evitar cache.
* Extração e padronização do CSS de administração.
* Adição de i18n e prefixos para prevenir colisões.
* Correção da lógica de verificação de permissões do `.htaccess` e `wp-config.php`.